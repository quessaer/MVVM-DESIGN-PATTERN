//
//  Constants.swift
//  MoviesApp
//
//  Created by Mohammad Azam on 7/27/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import Foundation

struct Constants {
    static let API_KEY = "YOURAPIKEY" // OMDBAPI
}
